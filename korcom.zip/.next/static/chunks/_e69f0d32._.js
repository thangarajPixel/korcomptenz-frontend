(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_480deb2e._.js",
  "static/chunks/8fa2a_next_dist_compiled_eddb0121._.js",
  "static/chunks/8fa2a_next_dist_client_fc2cfafe._.js",
  "static/chunks/8fa2a_next_dist_74184279._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
