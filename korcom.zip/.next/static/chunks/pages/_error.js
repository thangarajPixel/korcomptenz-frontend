__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root-of-the-server]__e0aad267._.js",
  "static/chunks/e9ecf_react-dom_86e1b5ce._.js",
  "static/chunks/node_modules__pnpm_a9ae11b9._.js",
  "static/chunks/[root-of-the-server]__923cb372._.js",
  "static/chunks/pages__error_5771e187._.js",
  "static/chunks/pages__error_dc39d318._.js"
])
