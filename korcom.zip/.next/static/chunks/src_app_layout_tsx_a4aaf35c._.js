(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__590ae6a4._.css",
  "static/chunks/node_modules__pnpm_031f2ced._.js",
  "static/chunks/src_393044d6._.js"
],
    source: "dynamic"
});
