(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__e0aad267._.js",
  "static/chunks/e9ecf_react-dom_86e1b5ce._.js",
  "static/chunks/node_modules__pnpm_a9ae11b9._.js",
  "static/chunks/[root-of-the-server]__923cb372._.js"
],
    source: "entry"
});
