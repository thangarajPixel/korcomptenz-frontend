"use client";

import React from "react";
import { Navbar } from "./navbar";

export function Header() {
  return (
    <React.Fragment>
      <Navbar />
    </React.Fragment>
  );
}
