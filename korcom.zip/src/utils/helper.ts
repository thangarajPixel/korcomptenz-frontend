import sampleJson from '../../public/json/sample.json';

export const jsonData = sampleJson;