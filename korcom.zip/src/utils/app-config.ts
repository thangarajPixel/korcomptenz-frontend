export const APP_CONFIG = {
  APP_NAME: 'Korcomptenz',
  APP_VERSION: '1.0.0',
  API_URL: process.env.NEXT_PUBLIC_API_URL,
};